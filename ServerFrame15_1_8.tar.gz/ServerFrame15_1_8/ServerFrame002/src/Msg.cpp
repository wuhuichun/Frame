#include "Msg.h"

Msg::Msg()
{
	//ctor
}

Msg::Msg(eCmd _cmd)
{
	//ctor
}

Msg::Msg(const Msg & _Msg)
{
	m_len = _Msg.m_len;
	m_cmd = _Msg.m_cmd;

	mp_buf = new char[m_len];
	memcpy(mp_buf, _Msg.mp_buf, m_len);

	//ctor
}

Msg::~Msg()
{
	//dtor
	if(mp_buf != nullptr)
	{
		delete [] mp_buf;
	}

}
