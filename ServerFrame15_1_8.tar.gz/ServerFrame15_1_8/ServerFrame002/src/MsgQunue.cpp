#include "MsgQunue.h"

MsgQunue::MsgQunue()
{
	//ctor
}

MsgQunue::~MsgQunue()
{
	//dtor
}

void MsgQunue::PushMsg(char * _pbuf)
{
	std::cout<<"Good u got:MsgBuf"<< *_pbuf<< std::endl;
}
